//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Benjamin Paul Cayton on 9/17/20.
//  Copyright © 2020 Benjamin Paul Cayton. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {
    
    @IBAction func unwindToQuizIntroduction(sugue: UIStoryboardSegue) {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

